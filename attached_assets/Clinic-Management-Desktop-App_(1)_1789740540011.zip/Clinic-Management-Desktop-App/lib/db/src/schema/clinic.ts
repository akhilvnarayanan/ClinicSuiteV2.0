import { createInsertSchema } from "drizzle-zod";
import {
  boolean,
  date,
  integer,
  numeric,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const patientsTable = pgTable(
  "patients",
  {
    id: serial("id").primaryKey(),
    patientNumber: text("patient_number").notNull(),
    fullName: text("full_name").notNull(),
    dateOfBirth: date("date_of_birth", { mode: "string" }),
    gender: text("gender"),
    phone: text("phone"),
    email: text("email"),
    address: text("address"),
    bloodGroup: text("blood_group"),
    allergies: text("allergies"),
    medicalConditions: text("medical_conditions"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => ({
    patientNumberIdx: uniqueIndex("patients_patient_number_idx").on(
      table.patientNumber,
    ),
  }),
);

export const doctorsTable = pgTable("doctors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialization: text("specialization").notNull().default("General Physician"),
  consultationFee: numeric("consultation_fee", {
    precision: 12,
    scale: 2,
  })
    .notNull()
    .default("0"),
  active: boolean("active").notNull().default(true),
});

export const servicesTable = pgTable("services", {
  id: serial("id").primaryKey(),
  serviceName: text("service_name").notNull(),
  price: numeric("price", { precision: 12, scale: 2 }).notNull().default("0"),
  active: boolean("active").notNull().default(true),
});

export const visitsTable = pgTable("visits", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id")
    .notNull()
    .references(() => patientsTable.id),
  doctorId: integer("doctor_id")
    .notNull()
    .references(() => doctorsTable.id),
  visitDate: timestamp("visit_date", { withTimezone: true })
    .notNull()
    .defaultNow(),
  visitType: text("visit_type").notNull().default("Consultation"),
  notes: text("notes"),
  consultationFee: numeric("consultation_fee", {
    precision: 12,
    scale: 2,
  })
    .notNull()
    .default("0"),
  status: text("status").notNull().default("Completed"),
});

export const visitServicesTable = pgTable("visit_services", {
  id: serial("id").primaryKey(),
  visitId: integer("visit_id")
    .notNull()
    .references(() => visitsTable.id, { onDelete: "cascade" }),
  serviceId: integer("service_id").references(() => servicesTable.id),
  serviceName: text("service_name").notNull(),
  quantity: integer("quantity").notNull().default(1),
  price: numeric("price", { precision: 12, scale: 2 }).notNull().default("0"),
  total: numeric("total", { precision: 12, scale: 2 }).notNull().default("0"),
});

export const paymentsTable = pgTable("payments", {
  id: serial("id").primaryKey(),
  visitId: integer("visit_id")
    .notNull()
    .references(() => visitsTable.id, { onDelete: "cascade" }),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  paymentMethod: text("payment_method").notNull(),
  paymentStatus: text("payment_status").notNull().default("Paid"),
  paymentDate: timestamp("payment_date", { withTimezone: true })
    .notNull()
    .defaultNow(),
  receiptNumber: text("receipt_number").notNull().unique(),
});

export const insertPatientSchema = createInsertSchema(patientsTable).omit({
  id: true,
  createdAt: true,
});
export const insertDoctorSchema = createInsertSchema(doctorsTable).omit({
  id: true,
});
export const insertServiceSchema = createInsertSchema(servicesTable).omit({
  id: true,
});
export type Patient = typeof patientsTable.$inferSelect;
export type Doctor = typeof doctorsTable.$inferSelect;
export type Service = typeof servicesTable.$inferSelect;
export type Visit = typeof visitsTable.$inferSelect;
export type Payment = typeof paymentsTable.$inferSelect;
export type VisitService = typeof visitServicesTable.$inferSelect;
export type InsertPatient = z.infer<typeof insertPatientSchema>;