import { Router, type IRouter } from "express";
import clinicRouter from "./clinic";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(clinicRouter);

export default router;
