---
name: Generated client TypeScript libs
description: Compiler configuration needed by Orval-generated fetch helpers in this workspace.
---

The generated API client uses `Headers.entries()`, so the `@workspace/api-client-react` TypeScript library must include both `dom` and `dom.iterable` in its compiler `lib` list.

**Why:** The workspace's generated client otherwise fails library typechecking even though code generation itself succeeds.

**How to apply:** Keep `dom.iterable` enabled whenever the generated API client or its Orval output is regenerated.