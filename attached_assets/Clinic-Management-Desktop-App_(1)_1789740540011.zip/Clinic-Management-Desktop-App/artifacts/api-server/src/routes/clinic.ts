import { Router, type Response } from "express";
import {
  AddPaymentBody,
  AddPaymentParams,
  CreateDoctorBody,
  CreatePatientBody,
  CreateServiceBody,
  CreateVisitBody,
  GetDailyReportQueryParams,
  GetPatientHistoryParams,
  GetPatientParams,
  GetVisitParams,
  ListPatientsQueryParams,
  ListVisitsQueryParams,
  UpdateDoctorBody,
  UpdateDoctorParams,
  UpdatePatientBody,
  UpdatePatientParams,
  UpdateServiceBody,
  UpdateServiceParams,
} from "@workspace/api-zod";
import { db } from "@workspace/db";
import {
  doctorsTable,
  paymentsTable,
  patientsTable,
  servicesTable,
  visitServicesTable,
  visitsTable,
} from "@workspace/db";
import { and, asc, desc, eq, ilike, or, sql } from "drizzle-orm";

const router = Router();

const money = (value: unknown) => Number(value ?? 0);
const isoDate = (value: Date | string | null | undefined) =>
  value instanceof Date ? value.toISOString() : value;
const calendarDate = (value: Date | string | null | undefined) =>
  value instanceof Date ? value.toISOString().slice(0, 10) : value ?? null;
const dayStart = (date: string) => new Date(`${date}T00:00:00.000Z`);
const dayEnd = (date: string) => new Date(`${date}T23:59:59.999Z`);
const today = () => new Date().toISOString().slice(0, 10);

function sendError(res: Response, status: number, message: string) {
  return res.status(status).json({ error: message });
}

async function ensureSeeds() {
  const [doctor] = await db.select({ id: doctorsTable.id }).from(doctorsTable).limit(1);
  if (!doctor) {
    await db.insert(doctorsTable).values({
      name: "Dr. Smith",
      specialization: "General Physician",
      consultationFee: "50",
    });
  }

  const [service] = await db.select({ id: servicesTable.id }).from(servicesTable).limit(1);
  if (!service) {
    await db.insert(servicesTable).values([
      { serviceName: "Stitching", price: "80" },
      { serviceName: "Dressing", price: "20" },
      { serviceName: "Injection", price: "15" },
      { serviceName: "Nebulization", price: "25" },
    ]);
  }
}

function serializePatient(patient: typeof patientsTable.$inferSelect) {
  return {
    id: patient.id,
    patientNumber: patient.patientNumber,
    fullName: patient.fullName,
    dateOfBirth: patient.dateOfBirth,
    gender: patient.gender,
    phone: patient.phone,
    email: patient.email,
    address: patient.address,
    bloodGroup: patient.bloodGroup,
    allergies: patient.allergies,
    medicalConditions: patient.medicalConditions,
    createdAt: patient.createdAt.toISOString(),
  };
}

function serializeDoctor(doctor: typeof doctorsTable.$inferSelect) {
  return {
    id: doctor.id,
    name: doctor.name,
    specialization: doctor.specialization,
    consultationFee: money(doctor.consultationFee),
    active: doctor.active,
  };
}

function serializeService(service: typeof servicesTable.$inferSelect) {
  return {
    id: service.id,
    serviceName: service.serviceName,
    price: money(service.price),
    active: service.active,
  };
}

async function loadVisit(id: number) {
  const [visit] = await db
    .select({
      visit: visitsTable,
      patientName: patientsTable.fullName,
      patientNumber: patientsTable.patientNumber,
      doctorName: doctorsTable.name,
    })
    .from(visitsTable)
    .innerJoin(patientsTable, eq(patientsTable.id, visitsTable.patientId))
    .innerJoin(doctorsTable, eq(doctorsTable.id, visitsTable.doctorId))
    .where(eq(visitsTable.id, id))
    .limit(1);

  if (!visit) return null;
  const [services, payments] = await Promise.all([
    db
      .select()
      .from(visitServicesTable)
      .where(eq(visitServicesTable.visitId, id))
      .orderBy(asc(visitServicesTable.id)),
    db
      .select()
      .from(paymentsTable)
      .where(eq(paymentsTable.visitId, id))
      .orderBy(desc(paymentsTable.paymentDate)),
  ]);

  const total =
    money(visit.visit.consultationFee) +
    services.reduce((sum, item) => sum + money(item.total), 0);
  const paid = payments.reduce((sum, payment) => sum + money(payment.amount), 0);

  return {
    id: visit.visit.id,
    patientId: visit.visit.patientId,
    patientName: visit.patientName,
    patientNumber: visit.patientNumber,
    doctorId: visit.visit.doctorId,
    doctorName: visit.doctorName,
    visitDate: isoDate(visit.visit.visitDate),
    visitType: visit.visit.visitType,
    notes: visit.visit.notes,
    consultationFee: money(visit.visit.consultationFee),
    services: services.map((item) => ({
      id: item.id,
      serviceId: item.serviceId,
      serviceName: item.serviceName,
      quantity: item.quantity,
      price: money(item.price),
      total: money(item.total),
    })),
    payments: payments.map((payment) => ({
      id: payment.id,
      amount: money(payment.amount),
      paymentMethod: payment.paymentMethod,
      paymentStatus: payment.paymentStatus,
      paymentDate: isoDate(payment.paymentDate),
      receiptNumber: payment.receiptNumber,
    })),
    total,
    paid,
    due: Math.max(total - paid, 0),
  };
}

async function loadVisits(date?: string) {
  const visits = await db
    .select({ id: visitsTable.id })
    .from(visitsTable)
    .where(
      date
        ? and(
            sql`${visitsTable.visitDate} >= ${dayStart(date)}`,
            sql`${visitsTable.visitDate} <= ${dayEnd(date)}`,
          )
        : undefined,
    )
    .orderBy(desc(visitsTable.visitDate))
    .limit(100);
  return (await Promise.all(visits.map((item) => loadVisit(item.id)))).filter(
    (item): item is NonNullable<typeof item> => item !== null,
  );
}

router.get("/dashboard", async (_req, res) => {
  try {
    await ensureSeeds();
    const [patientCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(patientsTable);
    const recentVisits = await loadVisits();
    const todaysVisits = recentVisits.filter((visit) =>
      String(visit.visitDate).startsWith(today()),
    );
    const todayRevenue = todaysVisits.reduce((sum, visit) => sum + visit.paid, 0);
    const outstanding = recentVisits.reduce((sum, visit) => sum + visit.due, 0);
    return res.json({
      patientCount: Number(patientCount?.count ?? 0),
      todayVisitCount: todaysVisits.length,
      todayRevenue,
      outstanding,
      recentVisits: recentVisits.slice(0, 5),
    });
  } catch (error) {
    res.log.error({ error }, "dashboard request failed");
    return sendError(res, 500, "Unable to load dashboard");
  }
});

router.get("/patients", async (req, res) => {
  try {
    const { search } = ListPatientsQueryParams.parse({
      search: typeof req.query.search === "string" ? req.query.search : undefined,
    });
    const term = search?.trim();
    const patients = await db
      .select()
      .from(patientsTable)
      .where(
        term
          ? or(
              ilike(patientsTable.fullName, `%${term}%`),
              ilike(patientsTable.phone, `%${term}%`),
              ilike(patientsTable.patientNumber, `%${term}%`),
            )
          : undefined,
      )
      .orderBy(desc(patientsTable.createdAt))
      .limit(100);
    return res.json(patients.map(serializePatient));
  } catch (error) {
    res.log.error({ error }, "patient list request failed");
    return sendError(res, 400, "Unable to load patients");
  }
});

router.post("/patients", async (req, res) => {
  try {
    const body = CreatePatientBody.parse(req.body);
    const patientNumber =
      body.patientNumber?.trim() ||
      `PT-${new Date().getFullYear()}-${String(Date.now()).slice(-5)}`;
    const [patient] = await db
      .insert(patientsTable)
      .values({
        patientNumber,
        fullName: body.fullName,
        dateOfBirth: calendarDate(body.dateOfBirth),
        gender: body.gender ?? null,
        phone: body.phone ?? null,
        email: body.email ?? null,
        address: body.address ?? null,
        bloodGroup: body.bloodGroup ?? null,
        allergies: body.allergies ?? null,
        medicalConditions: body.medicalConditions ?? null,
      })
      .returning();
    return res.status(201).json(serializePatient(patient));
  } catch (error) {
    res.log.error({ error }, "patient creation failed");
    return sendError(res, 400, "Unable to create patient");
  }
});

router.get("/patients/:id", async (req, res) => {
  try {
    const { id } = GetPatientParams.parse({ id: Number(req.params.id) });
    const [patient] = await db
      .select()
      .from(patientsTable)
      .where(eq(patientsTable.id, id))
      .limit(1);
    if (!patient) return sendError(res, 404, "Patient not found");
    return res.json({
      ...serializePatient(patient),
      history: await loadVisitsForPatient(id),
    });
  } catch (error) {
    res.log.error({ error }, "patient detail request failed");
    return sendError(res, 400, "Unable to load patient");
  }
});

async function loadVisitsForPatient(patientId: number) {
  const visits = await db
    .select({ id: visitsTable.id })
    .from(visitsTable)
    .where(eq(visitsTable.patientId, patientId))
    .orderBy(desc(visitsTable.visitDate));
  return (await Promise.all(visits.map((item) => loadVisit(item.id)))).filter(
    (item): item is NonNullable<typeof item> => item !== null,
  );
}

router.patch("/patients/:id", async (req, res) => {
  try {
    const { id } = UpdatePatientParams.parse({ id: Number(req.params.id) });
    const body = UpdatePatientBody.parse(req.body);
    const [patient] = await db
      .update(patientsTable)
      .set({
        patientNumber: body.patientNumber ?? undefined,
        fullName: body.fullName,
        dateOfBirth: calendarDate(body.dateOfBirth),
        gender: body.gender ?? null,
        phone: body.phone ?? null,
        email: body.email ?? null,
        address: body.address ?? null,
        bloodGroup: body.bloodGroup ?? null,
        allergies: body.allergies ?? null,
        medicalConditions: body.medicalConditions ?? null,
      })
      .where(eq(patientsTable.id, id))
      .returning();
    if (!patient) return sendError(res, 404, "Patient not found");
    return res.json(serializePatient(patient));
  } catch (error) {
    res.log.error({ error }, "patient update failed");
    return sendError(res, 400, "Unable to update patient");
  }
});

router.get("/patients/:id/history", async (req, res) => {
  try {
    const { id } = GetPatientHistoryParams.parse({ id: Number(req.params.id) });
    return res.json(await loadVisitsForPatient(id));
  } catch (error) {
    res.log.error({ error }, "patient history request failed");
    return sendError(res, 400, "Unable to load patient history");
  }
});

router.get("/doctors", async (_req, res) => {
  try {
    await ensureSeeds();
    const doctors = await db
      .select()
      .from(doctorsTable)
      .where(eq(doctorsTable.active, true))
      .orderBy(asc(doctorsTable.name));
    return res.json(doctors.map(serializeDoctor));
  } catch (error) {
    res.log.error({ error }, "doctor list request failed");
    return sendError(res, 500, "Unable to load doctors");
  }
});

router.post("/doctors", async (req, res) => {
  try {
    const body = CreateDoctorBody.parse(req.body);
    const [doctor] = await db
      .insert(doctorsTable)
      .values({
        name: body.name,
        specialization: body.specialization || "General Physician",
        consultationFee: String(body.consultationFee ?? 0),
      })
      .returning();
    return res.status(201).json(serializeDoctor(doctor));
  } catch (error) {
    res.log.error({ error }, "doctor creation failed");
    return sendError(res, 400, "Unable to create doctor");
  }
});

router.patch("/doctors/:id", async (req, res) => {
  try {
    const { id } = UpdateDoctorParams.parse({ id: Number(req.params.id) });
    const body = UpdateDoctorBody.parse(req.body);
    const [doctor] = await db
      .update(doctorsTable)
      .set({
        name: body.name,
        specialization: body.specialization,
        consultationFee: String(body.consultationFee ?? 0),
        active: body.active ?? true,
      })
      .where(eq(doctorsTable.id, id))
      .returning();
    if (!doctor) return sendError(res, 404, "Doctor not found");
    return res.json(serializeDoctor(doctor));
  } catch (error) {
    res.log.error({ error }, "doctor update failed");
    return sendError(res, 400, "Unable to update doctor");
  }
});

router.get("/services", async (_req, res) => {
  try {
    await ensureSeeds();
    const services = await db
      .select()
      .from(servicesTable)
      .where(eq(servicesTable.active, true))
      .orderBy(asc(servicesTable.serviceName));
    return res.json(services.map(serializeService));
  } catch (error) {
    res.log.error({ error }, "service list request failed");
    return sendError(res, 500, "Unable to load services");
  }
});

router.post("/services", async (req, res) => {
  try {
    const body = CreateServiceBody.parse(req.body);
    const [service] = await db
      .insert(servicesTable)
      .values({ serviceName: body.serviceName, price: String(body.price) })
      .returning();
    return res.status(201).json(serializeService(service));
  } catch (error) {
    res.log.error({ error }, "service creation failed");
    return sendError(res, 400, "Unable to create service");
  }
});

router.patch("/services/:id", async (req, res) => {
  try {
    const { id } = UpdateServiceParams.parse({ id: Number(req.params.id) });
    const body = UpdateServiceBody.parse(req.body);
    const [service] = await db
      .update(servicesTable)
      .set({
        serviceName: body.serviceName,
        price: String(body.price),
        active: body.active ?? true,
      })
      .where(eq(servicesTable.id, id))
      .returning();
    if (!service) return sendError(res, 404, "Service not found");
    return res.json(serializeService(service));
  } catch (error) {
    res.log.error({ error }, "service update failed");
    return sendError(res, 400, "Unable to update service");
  }
});

router.get("/visits", async (req, res) => {
  try {
    const { date } = ListVisitsQueryParams.parse({
      date: typeof req.query.date === "string" ? req.query.date : undefined,
    });
    return res.json(await loadVisits(calendarDate(date) ?? undefined));
  } catch (error) {
    res.log.error({ error }, "visit list request failed");
    return sendError(res, 400, "Unable to load visits");
  }
});

router.post("/visits", async (req, res) => {
  try {
    const body = CreateVisitBody.parse(req.body);
    const [patient] = await db
      .select()
      .from(patientsTable)
      .where(eq(patientsTable.id, body.patientId))
      .limit(1);
    const [doctor] = await db
      .select()
      .from(doctorsTable)
      .where(eq(doctorsTable.id, body.doctorId))
      .limit(1);
    if (!patient || !doctor) return sendError(res, 400, "Patient or doctor not found");

    const visit = await db.transaction(async (tx) => {
      const [created] = await tx
        .insert(visitsTable)
        .values({
          patientId: body.patientId,
          doctorId: body.doctorId,
          visitType: body.visitType,
          notes: body.notes ?? null,
          consultationFee: String(body.consultationFee),
        })
        .returning();

      for (const item of body.services ?? []) {
        const [service] = await tx
          .select()
          .from(servicesTable)
          .where(eq(servicesTable.id, item.serviceId))
          .limit(1);
        if (!service) continue;
        const price = money(service.price);
        await tx.insert(visitServicesTable).values({
          visitId: created.id,
          serviceId: service.id,
          serviceName: service.serviceName,
          quantity: item.quantity,
          price: String(price),
          total: String(price * item.quantity),
        });
      }

      if (body.payment) {
        await tx.insert(paymentsTable).values({
          visitId: created.id,
          amount: String(body.payment.amount),
          paymentMethod: body.payment.paymentMethod,
          receiptNumber: `RC-${Date.now()}-${created.id}`,
        });
      }
      return created;
    });
    return res.status(201).json(await loadVisit(visit.id));
  } catch (error) {
    res.log.error({ error }, "visit creation failed");
    return sendError(res, 400, "Unable to create visit");
  }
});

router.get("/visits/:id", async (req, res) => {
  try {
    const { id } = GetVisitParams.parse({ id: Number(req.params.id) });
    const visit = await loadVisit(id);
    if (!visit) return sendError(res, 404, "Visit not found");
    return res.json(visit);
  } catch (error) {
    res.log.error({ error }, "visit detail request failed");
    return sendError(res, 400, "Unable to load visit");
  }
});

router.post("/visits/:id/payments", async (req, res) => {
  try {
    const { id } = AddPaymentParams.parse({ id: Number(req.params.id) });
    const body = AddPaymentBody.parse(req.body);
    const visit = await loadVisit(id);
    if (!visit) return sendError(res, 404, "Visit not found");
    const [payment] = await db
      .insert(paymentsTable)
      .values({
        visitId: id,
        amount: String(body.amount),
        paymentMethod: body.paymentMethod,
        receiptNumber: `RC-${Date.now()}-${id}`,
      })
      .returning();
    return res.status(201).json({
      id: payment.id,
      amount: money(payment.amount),
      paymentMethod: payment.paymentMethod,
      paymentStatus: payment.paymentStatus,
      paymentDate: isoDate(payment.paymentDate),
      receiptNumber: payment.receiptNumber,
    });
  } catch (error) {
    res.log.error({ error }, "payment creation failed");
    return sendError(res, 400, "Unable to record payment");
  }
});

router.get("/reports/daily", async (req, res) => {
  try {
    const { date = today() } = GetDailyReportQueryParams.parse({
      date: typeof req.query.date === "string" ? req.query.date : undefined,
    });
    const reportDate = calendarDate(date) ?? today();
    const visits = await loadVisits(reportDate);
    const gross = visits.reduce((sum, visit) => sum + visit.total, 0);
    const paid = visits.reduce((sum, visit) => sum + visit.paid, 0);
    return res.json({
      date: reportDate,
      visitCount: visits.length,
      gross,
      paid,
      outstanding: Math.max(gross - paid, 0),
      visits,
    });
  } catch (error) {
    res.log.error({ error }, "daily report request failed");
    return sendError(res, 400, "Unable to load daily report");
  }
});

export default router;