# Clinic Management

Clinic Management helps small outpatient clinics register patients, record visits, bill services, collect payments, and reconcile the day.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/clinic-management` — React/Vite clinic workspace and routes
- `artifacts/api-server/src/routes/clinic.ts` — clinic API handlers and visit/payment workflow
- `lib/api-spec/openapi.yaml` — source of truth for API contracts and generated hooks
- `lib/db/src/schema/clinic.ts` — PostgreSQL schema for patients, doctors, services, visits, and payments

## Architecture decisions

- Visit creation is transactional: the visit, selected service line items, and the optional first payment are committed together.
- Services are copied onto visit line items at creation time so historical bills retain the price and name used that day.
- Dashboard and report totals are derived from persisted visits and payments rather than client-side-only state.
- The web workspace keeps the original MVP's patient/visit language while making billing and directory management usable in one browser app.

## Product

## Product

- Dashboard with patient count, today's visits, collections, outstanding balances, and recent visits
- Patient registration, search, editable profiles, and visit history
- Visit creation with doctor selection, consultation fee, services, quantities, and first payment
- Visit detail with charge breakdown, payment history, and follow-up payment entry
- Doctor and service/pricing management
- Daily report with gross, collected, outstanding, and visit handoff

## User preferences

The user chose to continue improving the uploaded Windows clinic MVP's workflow rather than change domains.

## Gotchas

After changing `lib/api-spec/openapi.yaml`, run `pnpm --filter @workspace/api-spec run codegen` before using generated API types.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
